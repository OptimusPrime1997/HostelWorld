package com.nju.entity;

import java.io.Serializable;

/**
 * Created by OptimusPrime on 2017.3.10.
 */
public class Payment implements Serializable{
	private String payno;
	private String hostelNo;
	private double inCome;
	private double ratio;
	private double fee;
	private double outcome;

	public Payment(String payno, String hostelNo, double inCome, double ratio, double fee, double outcome) {
		this.payno = payno;
		this.hostelNo = hostelNo;
		this.inCome = inCome;
		this.ratio = ratio;
		this.fee = fee;
		this.outcome = outcome;
	}

	public String getPayno() {
		return payno;
	}

	public void setPayno(String payno) {
		this.payno = payno;
	}

	public String getHostelNo() {
		return hostelNo;
	}

	public void setHostelNo(String hostelNo) {
		this.hostelNo = hostelNo;
	}

	public double getInCome() {
		return inCome;
	}

	public void setInCome(double inCome) {
		this.inCome = inCome;
	}

	public double getRatio() {
		return ratio;
	}

	public void setRatio(double ratio) {
		this.ratio = ratio;
	}

	public double getFee() {
		return fee;
	}

	public void setFee(double fee) {
		this.fee = fee;
	}

	public double getOutcome() {
		return outcome;
	}

	public void setOutcome(double outcome) {
		this.outcome = outcome;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		Payment payment = (Payment) o;

		if (Double.compare(payment.inCome, inCome) != 0) return false;
		if (Double.compare(payment.ratio, ratio) != 0) return false;
		if (Double.compare(payment.fee, fee) != 0) return false;
		if (Double.compare(payment.outcome, outcome) != 0) return false;
		if (payno != null ? !payno.equals(payment.payno) : payment.payno != null) return false;
		if (hostelNo != null ? !hostelNo.equals(payment.hostelNo) : payment.hostelNo != null) return false;

		return true;
	}

	@Override
	public int hashCode() {
		int result;
		long temp;
		result = payno != null ? payno.hashCode() : 0;
		result = 31 * result + (hostelNo != null ? hostelNo.hashCode() : 0);
		temp = Double.doubleToLongBits(inCome);
		result = 31 * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(ratio);
		result = 31 * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(fee);
		result = 31 * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(outcome);
		result = 31 * result + (int) (temp ^ (temp >>> 32));
		return result;
	}
}
