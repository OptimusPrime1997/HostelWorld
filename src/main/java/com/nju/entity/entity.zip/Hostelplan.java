package com.nju.entity;

import com.nju.util.RoomType;

import java.io.Serializable;

/**
 * Created by OptimusPrime on 2017.3.10.
 */
public class Hostelplan implements  Serializable{
	private String hostelplanno;
	private String hostelno;
	private RoomType roomType;
	private int price;

	public Hostelplan(String hostelplanno, String hostelno, RoomType roomType, int price) {
		this.hostelplanno = hostelplanno;
		this.hostelno = hostelno;
		this.roomType = roomType;
		this.price = price;
	}

	public String getHostelplanno() {
		return hostelplanno;
	}

	public void setHostelplanno(String hostelplanno) {
		this.hostelplanno = hostelplanno;
	}

	public String getHostelno() {
		return hostelno;
	}

	public void setHostelno(String hostelno) {
		this.hostelno = hostelno;
	}

	public RoomType getRoomType() {
		return roomType;
	}

	public void setRoomType(RoomType roomType) {
		this.roomType = roomType;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}


	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		Hostelplan that = (Hostelplan) o;

		if (price != that.price) return false;
		if (hostelplanno != null ? !hostelplanno.equals(that.hostelplanno) : that.hostelplanno != null) return false;
		if (hostelno != null ? !hostelno.equals(that.hostelno) : that.hostelno != null) return false;
		if (roomType != null ? !roomType.equals(that.roomType) : that.roomType != null) return false;

		return true;
	}

	@Override
	public int hashCode() {
		int result = hostelplanno != null ? hostelplanno.hashCode() : 0;
		result = 31 * result + (hostelno != null ? hostelno.hashCode() : 0);
		result = 31 * result + (roomType != null ? roomType.hashCode() : 0);
		result = 31 * result + price;
		return result;
	}
}
